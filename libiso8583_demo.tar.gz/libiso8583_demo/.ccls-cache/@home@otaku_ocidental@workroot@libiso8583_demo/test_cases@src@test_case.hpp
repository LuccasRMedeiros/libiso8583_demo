#ifndef TEST_CASE_HPP
#define TEST_CASE_HPP

#include <functional>
#include <string>

template<typename Rtype, typename... Args>
class TestCase
{
    private:
        std::string _test_title;
        std::function<Rtype(Args...)> _test_fn;

    public:
        TestCase(std::string test_title, std::function<Rtype(Args...)>test_fn);
};

#endif
